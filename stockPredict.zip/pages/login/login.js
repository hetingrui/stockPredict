// pages/login/login.js
//贺庭睿
const app=getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    name: '',
    pwd: '',
    nameinput: false,
    pwdinput: false,
  },
  //输入姓名
  nameinput: function (e) {
    this.setData({ name: e.detail.value });
    this.setData({ nameinput: true });

  },
  //输入密码
  pwdinput: function (e) {
    this.setData({ pwd: e.detail.value });
    this.setData({ pwdinput: true });
  },
  //登录
  login:function(){
    //console.log("登录")
    var that = this;
    wx.request({
      
      url: 'http://seugwjl.chinanorth.cloudapp.chinacloudapi.cn:8848/myapp/login',
      method: 'POST',
      data: {
        name: that.data.name,
        password: that.data.pwd
      },
      success: function (res) {
        if(res.data.state==true){
          console.log(res);
          wx.showToast({
            title: '登陆成功',
          });
          wx.setStorage({
            key: 'username',
            data: that.data.name,
          });
          wx.setStorage({
            key: 'isLogin',
            data: true,
          });
          var pages = getCurrentPages();
          var prevPage = pages[pages.length - 2];
          prevPage.setData({
            isLogin:true
          })
          wx.navigateBack({
            
          })
        }else{
          wx.showModal({
            title: '用户名或密码错误'
          })
        }
       
      },
      fail: function () {
        wx.showToast({
          title: '用户名或密码错误',
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})