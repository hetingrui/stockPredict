// pages/collection/collection.js
//贺庭睿
Page({

  /**
   * 页面的初始数据
   */
  data: {
    isLogin: false,
    username:'null'
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this
    wx.getStorage({
      key: 'isLogin',
      success: function(res) {
        if (res.data == true)
          that.setData({
            isLogin: true
          })
      }
    })
    wx.getStorage({
      key: 'username',
      success: function (res) {
        that.setData({
          username: res.data
        })
      },
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
   
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {
    var that = this
    wx.getStorage({
      key: 'isLogin',
      success: function (res) {
        if (res.data == true)
          that.setData({
            isLogin: true
          })
      }
    })
    wx.getStorage({
      key: 'username',
      success: function (res) {
        that.setData({
          username: res.data
        })
      },
    })
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },
  //复制链接
  CopyLink: function(e) {
    wx.setClipboardData({
      data: e.currentTarget.dataset.link,
      success: res => {
        wx.showToast({
          title: '已复制',
          duration: 1000,
        })
      }
    })
  },
  //登录键
  loginBtn: function() {
    wx.navigateTo({
      url: '../login/login',
    })
  },
  //退出键
  quit: function() {
    var that = this
    wx.showModal({
      title: '确定退出？',
      success(res) {
        if (res.confirm) {
          that.setData({
            isLogin: false
          })
          wx.clearStorage()
          wx.showToast({
            title: '已退出登录',
          })
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })

  }
})