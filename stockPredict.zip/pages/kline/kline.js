// pages/detail/detail.js
//贺庭睿
//绘制K线图
var base64 = require("../../images/base64");
//var dataObj = require("../data.js");
import * as echarts from '../component/ec-canvas/echarts';
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    ec: {
      lazyLoad: true
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this;
    var stockId = options.id;
    
    
    that.setData({
      icon20: base64.icon20,
      icon60: base64.icon60,
      stockId: stockId
    })

   
    that.getNews()
    //获取当前股价
    wx.request({
      url: 'https://hq.sinajs.cn/list=gb_' + stockId.toLowerCase(),
      method: 'GET',
      success: function (res) {
        console.log(res)
        let str = '';
        let str2 = '';
        str = res.data;
        str2 = str.substring(str.indexOf('"'))
        var elements = []
        elements = str2.split(',')
        console.log(elements)
        that.setData({
          elements: elements
        })
      }
    })
  },
  onReady: function () {
    // 获取组件
    this.ecComponent = this.selectComponent("#mychart-dom-area")
    this.initKLine()
  },
  //点击查看更多新闻
  // tapToSeeMore: function () {
  //   var that = this;
  //   wx.request({
  //     url: 'http://seugwjl.chinanorth.cloudapp.chinacloudapi.cn/myapp/news',
  //     method: 'POST',
  //     data: {

  //     },
  //     success: function (res) {
  //       console.log(res);
  //     },
  //     fail: function () {
  //       wx.showToast({
  //         title: '网络错误',
  //       })
  //     }
  //   })
  // },
  //获取新闻
  getNews: function () {
    var that = this;
    wx.request({
      url: 'http://seugwjl.chinanorth.cloudapp.chinacloudapi.cn:8848/myapp/getnews',
      method: 'POST',
      data: {
stockId:that.data.stockId
      },
      success: function (res) {
        var newslist = [[], []]
        newslist = res.data
        that.setData({
          newslist: res.data
        })
      },
      fail: function () {
        wx.showToast({
          title: '网络错误',
        })
      }
    })
  },
  //查看第一条新闻
  newsdetail1: function () {
    var that = this;
    wx.navigateTo({
      url: '../news/news?id=0',
    })
  },
  //查看第二条新闻
  newsdetail2: function () {
    var that = this;
    wx.navigateTo({
      url: '../news/news?id=1',
    })
  },
  //切换为折线图
  changeLine() {
    wx.navigateBack()
  },
  //初始化K线图
  initKLine: function () {
    this.ecComponent.init((canvas, width, height) => {
      const chart = echarts.init(canvas, null, {
        width: width,
        height: height
      });
      this.setOption(chart)
      this.chart = chart;
      return chart;
    })
  },
  //设置K线图参数
  setOption: function (chart) {
    let kdata,date,min
    wx.getStorage({
      key: 'kline',
      success: function (res) {
          kdata= res.data.kdata;
          date=res.data.date;
          min=res.data.min;
        var option = {
          xAxis: {
            axisLabel: {
              show: true,
              textStyle: {
                fontSize: 14 
              }
            },
            data: date,
          },
          yAxis: {
            x: 'center',
            type: 'value',
           
            splitLine: {
              lineStyle: {
                type: 'dashed'
              }
            },
            min:min
          },
          grid: {
            x: 30,
            y: 20,
            x2: 30,
            y2: 20,
          },
          series: [{
            type: 'k',
            data: kdata,
            grid: {
              top: 0,
            },
            itemStyle: {
              normal: {
                color: '#e64340',
                color0: '#09bb07',
                borderWidth: 1,
                opacity: 1,
              }
            }
          }]
        }
        chart.setOption(option)
      }
    })
    
   
    // return option;
  }


})