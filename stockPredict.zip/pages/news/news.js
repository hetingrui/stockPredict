//贺庭睿
//新闻显示
Page({

  /**
   * 页面的初始数据
   */
  data: {
    news: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var id;
    id = options.id
    var that = this;
    //获取新闻
    wx.getStorage({
      key: 'stockId',
      success: function(res) {
        wx.request({
          url: 'http://seugwjl.chinanorth.cloudapp.chinacloudapi.cn:8848/myapp/getnews',
          method: 'POST',
          data: {
            stockId: res.data
          },
          success: function(res) {
            var newslist = [
              [],
              []
            ]
            newslist = res.data
            that.setData({
              news: res.data[id]
            })
          },
          fail: function() {
            wx.showToast({
              title: '网络错误',
            })
          }
        })
      },
    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})