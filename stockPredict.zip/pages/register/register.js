//注册
//贺庭睿
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    name: '',
    pwd: '',
    pwd2: '',
    nameinput: false,
    pwdinput: false,
    pwdinput2: false
  },
  //输入姓名
  nameinput: function (e) {
    this.setData({ name: e.detail.value });
    this.setData({ nameinput: true });

  },
  //输入密码
  pwdinput: function (e) {
    this.setData({ pwd: e.detail.value });
    this.setData({ pwdinput: true });
  },
  //再次输入密码
  pwdinput2: function (e) {
    this.setData({ pwd2: e.detail.value });
    this.setData({ pwdinput2: true });
  },
  //比较密码是否相等
  comparePwd: function () {
    var that = this;
    let pw, pw2;
    pw = that.data.pwd;
    pw2 = that.data.pwd2;

    if (pw == pw2) {
      return true;
    } else {
      return false;
    }
  },
  //检查密码长度是否符合
  checkLength: function () {
    var that=this;
    if (!/^\w{6,16}$/g.test(that.data.pwd)) {
      return false;
    }else{
      return true;
    }
  },
  //检测是否为英文和数字
  checkEng:function(){
    var that = this;
    if (!/^[A-Za-z0-9]+$/g.test(that.data.pwd)) {
      return false;
    } else {
      return true;
    }
  },
  //检测用户名是否为英文和数字
  checkName: function () {
    var that = this;
    if (!/^[A-Za-z0-9]+$/g.test(that.data.name)) {
      return false;
    } else {
      return true;
    }
  },
  //注册
  register: function () {
    var that = this;
    if (that.comparePwd() == false) {
      wx.showModal({
        title: '密码不一致',
      })
    } else if(that.checkName()==false){
      wx.showModal({
        title: "必须为英文或数字",
      })
    }
    else if(that.checkLength()==false){
      wx.showModal({
        title: "密码不是6~16位",
        icon: 'warn'
      })
    }else if(that.checkEng()==false){
      wx.showModal({
        title: "密码必须为纯英文或数字",
        icon: 'warn'
      })
    }else{
      wx.request({
        url: 'http://seugwjl.chinanorth.cloudapp.chinacloudapi.cn:8848/myapp/register',
        method: 'POST',
        data: {
          name: that.data.name,
          password: that.data.pwd
        },
        success: function (res) {
          
          if(res.data.result=='exist'){       
            console.log(res);
            wx.showModal({
              title: '用户名已存在',
            })
          } else if (res.data.result=='success'){
            console.log(res);
            wx.showToast({
              title: '注册成功',
            });
            wx.setStorage({
              key: 'username',
              data: that.data.name,
            });
            wx.setStorage({
              key: 'isLogin',
              data: true,
            });
            wx.navigateBack({

            })
          }else{
            console.log(res);
            wx.showModal({
              title: '服务器故障',
            })
          }
        },
        fail: function () {
          wx.showToast({
            title: '用户名或密码错误',
          })
        }
      })
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})