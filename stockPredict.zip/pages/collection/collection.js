// pages/collection/collection.js
//贺庭睿
var base64 = require("../../images/base64");
var dataObj = require("../data.js");
Page({

  /**
   * 页面的初始数据
   */
  data: {
    username: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.setData({
      // stockList: dataObj.stockList,
      icon: base64.icon20,
      slideButtons: [
        {
          src: '../../../images/icon_del.svg', // icon的路径
        }
      ],
    })
    var that = this;
    //获取个人收藏信息
    wx.getStorage({
      key: 'username',
      success: function(res) {
        that.setData({
          username: res.data
        })
        console.log(res.data)
        wx.request({
          url: 'http://seugwjl.chinanorth.cloudapp.chinacloudapi.cn:8848/myapp/getcollection',
          method: 'POST',
          data: {
            name: res.data,
          },
          success: function(res) {
            console.log(res)
            that.setData({
              stockList: res.data
            })
          },
          fail(error) {
            wx.showToast({
              title: '网络错误',
            })
          }
        })
      },
    })


  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {
    wx.request({
      url: 'http://seugwjl.chinanorth.cloudapp.chinacloudapi.cn:8848/myapp/getcollection',
      method: 'POST',
      data: {
        name: that.data.username,
      },
      success: function(res) {
        console.log(res)
        that.setData({
          stockList: res.data
        })
      },
      fail(error) {

      }
    })
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },
  //查看股票详情
  checkDetail: function(e) {
    var edata = e.currentTarget.dataset;
   
    wx.navigateTo({
      url: '../detail/detail?id=' + edata.stockid,
    })
    wx.setStorage({
      key: 'stockId',
      data: edata.stockid,
    })
  },

  //相应滑动按钮的点击
  slideButtonTap(e) {
    var edata = e.currentTarget.dataset;
    var name = ''
    var stockId = ''
    var that = this

    name = that.data.username
    stockId = edata.stockid
    console.log(name)
    console.log(stockId)
    wx.request({
      url: 'http://seugwjl.chinanorth.cloudapp.chinacloudapi.cn:8848/myapp/delcollection',
      method: 'POST',
      data: {
        name: name,
        collections: stockId
      },
      success: function(res) {
        if (res.data.result) {
          wx.showToast({
            title: '删除成功'
          })
          wx.request({
            url: 'http://seugwjl.chinanorth.cloudapp.chinacloudapi.cn:8848/myapp/getcollection',
            method: 'POST',
            data: {
              name: that.data.username,
            },
            success: function(res) {
              console.log(res)
              that.setData({
                stockList: res.data
              })
            },
            fail(error) {

            }
          })
        } else {
          console.log(res)
          wx.showToast({
            icon: 'warn',
            title: '删除失败'
          })
        }
      }
    })


  }
})