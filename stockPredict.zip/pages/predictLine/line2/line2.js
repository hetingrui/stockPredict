// pages/detail/detail.js
//贺庭睿
var base64 = require("../../../images/base64");
//var dataObj = require("../../data.js");
import * as echarts from '../../component/ec-canvas/echarts';
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    ec: {
      lazyLoad: true
    }
    //predict2: dataObj.predict2
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.setData({
      icon20: base64.icon20,
      icon60: base64.icon60,
      stockId: options.id
    })
    // wx.showToast({
    //   title: '数据加载中',
    //   icon: 'loading',
    //   duration: 5000
    // });

    console.log(this.data.predict2)
  },
  onReady: function() {
    // 获取组件
    this.ecComponent = this.selectComponent("#mychart-dom-line")
    this.initLine()
  },

  //绘制折线
  initLine: function() {
    this.ecComponent.init((canvas, width, height) => {
      const chart = echarts.init(canvas, null, {
        width: width,
        height: height
      });
      this.setOption(chart)
      this.chart = chart;
      return chart;
    })
  },
  //设置图像的值
  setOption: function(chart) {
    var act = []
    var pre = []
    var line1, line2, line3, line4, line5, line6, line7
    var vert
   var that=this
        wx.request({
          url: 'http://seugwjl.chinanorth.cloudapp.chinacloudapi.cn:8848/myapp/predict2',
          method: 'POST',
          data: {
            stockId: that.data.stockId
          },
          success: function(res) {
            act = res.data.actual,
              line1 = res.data.l1,
              line2 = res.data.l2,
              line3 = res.data.l3,
              line4 = res.data.l4,
              line5 = res.data.l5,
              line6 = res.data.l6,
              line7 = res.data.l7,
              vert = res.data.verticle_line_x

            var option = {
              color: ["#37A2DA", "#67E0E3", "#9FE6B8", "#50bba7"],
              legend: {
                data: ['A', 'B'],
                top: 0,
                left: 'center',
                z: 100
              },
              grid: {
                containLabel: true,
                top: '4%',
                left: '3%',
                right: '4%',
                bottom: '3%',
              },
              tooltip: {
                show: true,
                trigger: 'axis',
                axisPointer: {
                  type: 'cross'
                }
              },
              xAxis: {
                type: 'category',
                boundaryGap: false,
                axisTick: {
                  alignWithLabel: true
                },
                axisLabel: {
                  show: true,
                  textStyle: {
                    fontSize: 14
                  }
                },
                splitLine: {
                  show: true,
                  interval: vert[0] - 1
                }
                // show: false

              },
              yAxis: {
                x: 'center',
                type: 'value',
                axisLabel: {
                  show: true,
                  textStyle: {
                    fontSize: 14
                  }
                },
                splitLine: {
                  lineStyle: {
                    type: 'dashed'
                  }
                }
                // show: false
              },
              series: [{
                  name: 'Act',
                  type: 'line',
                  smooth: true,
                  data: act
                },
                {
                  name: '曲线1',
                  symbolSize: 5,
                  data: line1,
                  type: 'line',
                  smooth: true,
                  showSymbol: false,
                  barGap: 0
                }, {
                  name: '曲线2',
                  symbolSize: 5,
                  data: line2,
                  type: 'line',
                  smooth: true,
                  showSymbol: false,
                  barGap: 0
                }, {
                  name: '曲线3',
                  symbolSize: 5,
                  data: line3,
                  type: 'line',
                  smooth: true,
                  showSymbol: false,
                  barGap: 0
                }, {
                  name: '曲线4',
                  symbolSize: 5,
                  data: line4,
                  type: 'line',
                  smooth: true,
                  showSymbol: false,
                  barGap: 0
                }, {
                  name: '曲线5',
                  symbolSize: 5,
                  data: line5,
                  type: 'line',
                  smooth: true,
                  showSymbol: false,
                  barGap: 0
                }, {
                  name: '曲线6',
                  symbolSize: 5,
                  data: line6,
                  type: 'line',
                  smooth: true,
                  showSymbol: false,
                  barGap: 0
                }, {
                  name: '曲线7',
                  symbolSize: 5,
                  data: line7,
                  type: 'line',
                  smooth: true,
                  showSymbol: false,
                  barGap: 0
                }
              ],

            };
            chart.setOption(option)
          }
        })
   
  }
  
})