// pages/detail/detail.js
//贺庭睿
var base64 = require("../../../images/base64");
//var dataObj = require("../../data.js");
import * as echarts from '../../component/ec-canvas/echarts';
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    ec: {
      lazyLoad: true
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.setData({
      icon20: base64.icon20,
      icon60: base64.icon60,
      stockId: options.id
    })

    // console.log(this.data.predict3)
  },
  onReady: function() {
    // 获取组件
    this.ecComponent = this.selectComponent("#mychart-dom-line")
    this.initLine()
  },
  initLine: function() {
    this.ecComponent.init((canvas, width, height) => {
      const chart = echarts.init(canvas, null, {
        width: width,
        height: height
      });
      this.setOption(chart)
      this.chart = chart;
      return chart;
    })
  },
  //设置图像的值
  setOption: function(chart) {
    var that = this
    var portfolio = []

    wx.request({
      url: 'http://seugwjl.chinanorth.cloudapp.chinacloudapi.cn:8848/myapp/predict4',
      method: 'POST',
      data: {
        stockId: that.data.stockId
      },
      success: function(res) {
        console.log(res)
        portfolio = res.data.portfolio
        var option = {
          color: ["#37A2DA", "#67E0E3", "#9FE6B8", "#50bba7"],
          grid: {
            containLabel: true,
            top: '4%',
            left: '3%',
            right: '4%',
            bottom: '3%',
          },
          tooltip: {
            show: true,
            trigger: 'axis',
            axisPointer: {
              type: 'cross'
            }
          },
          xAxis: {
            type: 'category',
            boundaryGap: false,
            axisTick: {
              alignWithLabel: true
            }
            // show: false
          },
          yAxis: {
            x: 'center',
            type: 'value',
            splitLine: {
              lineStyle: {
                type: 'dashed'
              }
            }
            // show: false
          },
          series: [{
            name: 'Por',
            type: 'line',
            smooth: true,
            data: portfolio
          }]
        };
        chart.setOption(option)
      }
    })




  }
  // fail: function () {
  //   wx.showToast({
  //     title: '网络异常',
  //   })
  // }
  // })
  // return option;
  // }
})