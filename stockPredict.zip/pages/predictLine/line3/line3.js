// pages/detail/detail.js
//贺庭睿
var base64 = require("../../../images/base64");
//var dataObj = require("../../data.js");
import * as echarts from '../../component/ec-canvas/echarts';
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    ec: {
      lazyLoad: true
    }
    //predict4: dataObj.predict4
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.setData({
      icon20: base64.icon20,
      icon60: base64.icon60,
      stockId: options.id
    })

  },
  onReady: function() {
    // 获取组件
    this.ecComponent = this.selectComponent("#mychart-dom-line")
    this.initLine()
  },
  initLine: function() {
    this.ecComponent.init((canvas, width, height) => {
      const chart = echarts.init(canvas, null, {
        width: width,
        height: height
      });
      this.setOption(chart)
      this.chart = chart;
      return chart;
    })
  },
  //设置图像的值
  setOption: function(chart) {
    var predict3
    var that = this
    wx.request({
      url: 'http://seugwjl.chinanorth.cloudapp.chinacloudapi.cn:8848/myapp/predict3',
      method: 'POST',
      data: {
        stockId: that.data.stockId
      },
      success: function(res) {
        predict3=res.data
        var option = {
          color: ['#515151'],
          tooltip: {
            trigger: 'axis'
          },
          xAxis: {
            type: 'category',
            boundaryGap: false,
            data: predict3.datual_xaxis
          },
          yAxis: {
            type: 'value'
          },
          series: [{
            type: 'line',
            data: predict3.actual_yaxis,
            markPoint: {
              data: predict3.markpoint,
              symbol: 'circle',
              symbolSize: 4

            }
          }]
        };
        chart.setOption(option)
      }
    })
  }
})