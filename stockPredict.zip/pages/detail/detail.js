// pages/detail/detail.js
var base64 = require("../../images/base64");
//var dataObj = require("../data.js");//从缓存中读取数据
import * as echarts from '../component/ec-canvas/echarts';
const app = getApp();
Page({
  /**
   * 页面的初始数据
   */
  data: {
    ec: {
      lazyLoad: true
    },
    open:'',
    high:'',
    low:'',
    stockId:'',
    predictable:false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var stockId =''
    stockId= options.id;
    console.log(stockId)
    this.setData({
      icon20: base64.icon20,
      icon60: base64.icon60,
      stockId: stockId
    })
    var that=this
    //检查是否可预测
    wx.request({
      url: 'http://seugwjl.chinanorth.cloudapp.chinacloudapi.cn:8848/myapp/ispredictable',
      method: 'POST',
      data: {
        stockId: that.data.stockId
      },
      success: function (res) {
        that.setData({
          predictable:res.data.result
        })
       },
      fail: function () {
        wx.showToast({
          title: '网络异常',
        })
        that.setData({
          predictable:false
        })
      }

    })
    //获取当前股价
    wx.request({
      url: 'http://hq.sinajs.cn/list=gb_' + stockId.toLowerCase(),
      method:'GET',
      success:function(res){
        console.log(res)
        let str='';
        let str2='';
        str=res.data;
        str2=str.substring(str.indexOf('"'))
        var elements=[]
        elements=str2.split(',')
        console.log(elements)
        that.setData({
          elements:elements
        })
      },
      fail: function () {
        wx.showToast({
          title: '网络错误',
        })
      }
    }),
    this.getNews()
    wx.showToast({
      title: '数据加载中',
      icon: 'loading',
      duration: 2500
    });
    
  },
  onReady: function() {  
    // 获取组件
    this.ecComponent = this.selectComponent("#mychart-dom-line")
    this.initLine()
   
  },
  // tapToSeeMore: function() {
   
  // },
  //初始化折线图信息
  initLine: function() {
    this.ecComponent.init((canvas, width, height) => {
      const chart = echarts.init(canvas, null, {
        width: width,
        height: height
      });
      this.setOption(chart)
      this.chart = chart;
      return chart;
    })
  },
  //设置图像的值
  setOption:function(chart) {
  var that=this
  //分别表示最高价、最低价、开盘价、收盘价
  var high = [0, 0, 0, 0, 0, 0, 0]
  var low = [0, 0, 0, 0, 0, 0, 0]
  var open = [0, 0, 0, 0, 0, 0, 0]
  var close = [0, 0, 0, 0, 0, 0, 0]
  //Y轴最小值，减少空白面积
  var ymin = 0
  var date = ['', '', '', '', '', '', '']
  wx.request({
      url: 'http://seugwjl.chinanorth.cloudapp.chinacloudapi.cn:8848/myapp/gethisdata',
      method: 'POST',
      data: {
        stockId: that.data.stockId
      },
      success: function (res) {
        high = res.data.High
        low = res.data.Low
        open = res.data.Open
        close = res.data.Close
        ymin = res.data.Min
        
        let i, today, t_date, str
        today = new Date()
        t_date = new Date(date)
        for (i = 0; i < 7; i++) {
          t_date.setFullYear(today.getFullYear());
          t_date.setMonth(today.getMonth() + 1);
          t_date.setDate(today.getDate() - 7 + i);
          str = t_date.getMonth() + '/' + t_date.getDate();
          //console.log(str)
          date[i] = str
        }

        var kdata = [[0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0]]
        let t;
        for (t = 0; t < 7; t++) {
          kdata[t][0] = open[t];
          kdata[t][1] = close[t];
          kdata[t][2] = low[t];
          kdata[t][3] = high[t];
        }
        console.log(kdata)
        //存储k线图所需数据
        var kline={'kdata':kdata,'min':ymin,'date':date}
        wx.setStorage({
          key: 'kline',
          data: kline,
        })
        var option = {
          color: ["#e74c3c", "#2980b9", "#27ae60", "#f9f900"],
          
          legend: {
            data: ['High', 'Low', 'Open', 'Close'],
            top: 0,
            left: 'center',
            z: 100
          },
          grid: {
            containLabel: true,
            top: '4%',
            left: '3%',
            right: '4%',
            bottom: '3%',
          },
          tooltip: {
            show: true,
            trigger: 'axis',
            axisPointer: {
              type: 'cross'
            }
            //,
           // confine: true
          },
          xAxis: {
            type: 'category',
            boundaryGap: false,
            axisTick: {
              alignWithLabel: true
            },
            data: date,
           
            // show: false
          },
          yAxis: {
            x: 'center',
            type: 'value',
            splitLine: {
              lineStyle: {
                type: 'dashed'
              },
            },
            min: ymin - 1
            // show: false
          },
          series: [
            {
            name: 'High',
            type: 'line',
            smooth: true,
            data: high
          }, {
            name: 'Low',
            type: 'line',
            smooth: true,
            data: low
          },
          {
            name: 'Open',
            type: 'line',
            smooth: true,
            data: open
          },
          {
            name: 'Close',
            type: 'line',
            smooth: true,
            data: close
          },
          ]
        };
        chart.setOption(option)
      },
      fail: function () {
        wx.showToast({
          title: '网络异常',
        })
      }
    })
    // return option;
  },
  //获取新闻
  getNews:function(){
    var that = this;
    wx.request({
      url: 'http://seugwjl.chinanorth.cloudapp.chinacloudapi.cn:8848/myapp/getnews',
      method: 'POST',
      data: {
        stockId:that.data.stockId
      },
      success: function (res) {
        var newslist = [[], []]
        newslist = res.data
          that.setData({
            newslist: res.data
          })
      },
      fail: function () {
        wx.showToast({
          title: '网络错误',
        })
      }
    })
  },
  //查看第一条新闻
  newsdetail1:function(){
    var that=this;
    wx.navigateTo({
      url: '../news/news?id=0',
    })
  },
  //查看第二条新闻
  newsdetail2: function () {
    var that = this;
    wx.navigateTo({
      url: '../news/news?id=1',
    })
  },
  //查看四条预测曲线
  open: function () {
    var that=this
    wx.showActionSheet({
      itemList: ['走势预测图', '阶段性预测图', '买入/卖出点预测图','消费者收益预测图'],
      success: function (res) {
        if (!res.cancel) {
          console.log(res.tapIndex)
          if (res.tapIndex==0){
            wx.navigateTo({
              url: '../predictLine/line1/line1?id='+that.data.stockId,
            })
          } else if (res.tapIndex == 1){
            wx.navigateTo({
              url: '../predictLine/line2/line2?id=' + that.data.stockId,
            })
          } else if (res.tapIndex == 2) {
            wx.navigateTo({
              url: '../predictLine/line3/line3?id=' + that.data.stockId,
            })
          } else if (res.tapIndex == 3) {
            wx.navigateTo({
              url: '../predictLine/line4/line4?id=' + that.data.stockId,
            })
          }else{
            console.log('按键异常')
          }
        }
      }
    });
  }
})