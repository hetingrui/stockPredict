//贺庭睿 搜索页面、股票推荐页面
var base64 = require("../../images/base64");
//var dataObj = require("../data.js");
Page({
  data: {
    inputShowed: false,
    inputVal: "",
    searchResult: []
  },
  onLoad() {
    this.setData({
      // stockList: dataObj.stockList,
      icon: base64.icon20,
      slideButtons: [
        //   {
        //   src: '../../../images/icon_love.svg', // icon的路径
        // },
        {
          src: '../../../images/icon_star.svg', // icon的路径
        }
        // {
        //   src: '../../../images/icon_del.svg', // icon的路径
        // }
      ],
    })
    var that=this
    wx.request({
      url: 'http://seugwjl.chinanorth.cloudapp.chinacloudapi.cn:8848/myapp/getstock',
      method: 'GET',
      data: {},
      success: function(res) {
        console.log(res)
        that.setData({
          stockList:res.data
        })
        },
      fail(error) {
        wx.showModal({
          title: '网络异常'
        })
      }
    })
  },
  onShow() {

  },
  showInput: function() {
    this.setData({
      inputShowed: true
    });
  },
  hideInput: function() {
    this.setData({
      inputVal: "",
      inputShowed: false
    });
  },
  clearInput: function() {
    this.setData({
      inputVal: ""
    });
  },
  inputTyping: function(e) {
    this.setData({
      inputVal: e.detail.value
    });
    var that = this;
    wx.request({
      url: 'http://seugwjl.chinanorth.cloudapp.chinacloudapi.cn:8848/myapp/searchstock',
      method: 'POST',
      data: {
        stockId: e.detail.value
      },
      success: function(res) {
        console.log(res)
        that.setData({
          searchResult: res.data
        })
      },
      fail: function() {
        wx.showToast({
          title: '网络异常',
        })
      }
    })
  },
  checkDetail: function(e) {
    var edata = e.currentTarget.dataset;
    wx.navigateTo({
      url: '../detail/detail?id=' + edata.stockid,
    })
    wx.setStorage({
      key: 'stockId',
      data: edata.stockid,
    })
  },
  inputComplete: function() {
    wx.navigateTo({
      url: '../searchResult/searchResult?searchStr=' + this.data.inputVal,
    })
  },
  // moreOperation: function() {
  //   wx.showActionSheet({
  //     itemList: ['收藏', '买入', '卖出'],
  //     success: function(res) {
  //       if (!res.cancel) {
  //         console.log(res.tapIndex)
  //       }
  //     }
  //   });
  // },
  slideButtonTap(e) {
    var edata = e.currentTarget.dataset;
    var name = ''
    var stockId = ''
    wx.getStorage({
      key: 'isLogin',
      success: function(res) {
        if (res.data == true) {
          wx.getStorage({
            key: 'username',
            success: function(res) {
              name = res.data
              stockId = edata.stockid
              console.log(name)
              console.log(stockId)
              wx.request({
                url: 'http://seugwjl.chinanorth.cloudapp.chinacloudapi.cn:8848/myapp/addcollection',
                method: 'POST',
                data: {
                  name: name,
                  collections: stockId
                },
                success: function(res) {
                  if (res.data.result)
                    wx.showToast({
                      title: '收藏成功'
                    })
                  else {
                    console.log(res)
                    wx.showToast({
                      icon: 'warn',
                      title: '收藏失败'
                    })
                  }
                }
              })

            },
          })
        } else {}
      },
      fail(error) {

        wx.showModal({
          title: '数据异常'
        })
      }
    })


    // wx.showModal({
    //   title:edata.stockid,
    // })

    // wx.request({
    //   url: 'http://seugwjl.chinanorth.cloudapp.chinacloudapi.cn:8848/myapp/collection',
    // })
  }

})